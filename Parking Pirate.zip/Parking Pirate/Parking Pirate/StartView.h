//
//  ViewController.h
//  Parking Pirate
//
//  Created by Nicolas Charlet on 4/23/14.
//  Copyright (c) 2014 Nicolas Charlet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StartView : UIViewController


@end
