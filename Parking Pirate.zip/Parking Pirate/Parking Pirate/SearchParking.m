//
//  ViewController2.m
//  Parking Pirate
//
//  Created by Nicolas Charlet on 4/23/14.
//  Copyright (c) 2014 Nicolas Charlet. All rights reserved.
//

#import "SearchParking.h"
#import "mapViewController.h"

@interface SearchParking ()

@end

@implementation SearchParking

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/




//- (IBAction)ShowTimeButton:(id)sender {
//    NSDateFormatter *formatter = [NSDateFormatter new];
//    formatter.dateFormat = @"EEEE hh:mm";
//    NSString * str = [formatter stringFromDate:_TimeCTRL.date];
//    
//    self.textField.text = str;
//    
//}
//
//- (IBAction)ShowTimeButtonClicked:(id)sender {
//}
- (IBAction)SetTimeClicker:(id)sender {
    
    NSDateFormatter *formatter = [NSDateFormatter new];
        formatter.dateFormat = @"hh:mm";
        NSString *str = [formatter stringFromDate:_TimeScrolling.date];
    
        self.DisplayTimeField.text = str;
}

-(void)searchingViewController:(SearchingViewController *)svc currentLocation:(NSDictionary *)loc
{
    self.chosenLocation = loc;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString: @"MainMapSegue"]) {
        mapViewController * vc = [segue destinationViewController];
        
        vc.centralLocation = self.chosenLocation;
    }
    else if ([segue.identifier isEqualToString:@"SearchGoogleSegue"])
    {
        SearchingViewController * vc = [segue destinationViewController];
        vc.delegate = self;
    }
}

- (IBAction)goBackToMainView:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end




















